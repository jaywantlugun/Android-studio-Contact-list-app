package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class contact_splash : AppCompatActivity() {

    lateinit var handler: Handler
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_splash)

        handler = Handler()
        handler.postDelayed({
            val intent= Intent(this,contact2::class.java)
            startActivity(intent)
            finish()
        }, 4000)   //delay 3second


    }
}