package com.example.myapplication.model

data class UserData (
    var userName:String,
    var userMb:String
)