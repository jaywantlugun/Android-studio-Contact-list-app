package com.example.myapplication

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.model.UserData
import com.example.myapplication.view.UserAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.activity_contact2.*
import kotlinx.android.synthetic.main.add_item.*


class contact2 : AppCompatActivity() {
    var flag=1
    private lateinit var addsBtn:FloatingActionButton
    private lateinit var recv:RecyclerView
    private lateinit var userList: ArrayList<UserData>
    private lateinit var userAdapter: UserAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact2)


        //set List
        userList= ArrayList()
        //set find id
        addsBtn=findViewById(R.id.addingBtn)
        recv=findViewById(R.id.mRecycler)
        //set Adapter
        userAdapter= UserAdapter(this,userList)
        //Set RecycleView adapter
        recv.layoutManager=LinearLayoutManager(this)
        recv.adapter=userAdapter
        //set Dialog
        addsBtn.setOnClickListener{ addInfo()}

        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener{
            Toast.makeText(this,"Navigation Menu Clicked",Toast.LENGTH_SHORT).show()
        }

    }




    private fun addInfo() {
        val inflter=LayoutInflater.from(this)
        val v=inflter.inflate(R.layout.add_item,null)

        //Set View
        val userName=v.findViewById<EditText>(R.id.userName)
        val userNo=v.findViewById<EditText>(R.id.userNo)

        val addDialog=AlertDialog.Builder(this)
        addDialog.setView(v)
        addDialog.setPositiveButton("Ok"){
            dialog,_->
            val names=userName.text.toString()
            val number=userNo.text.toString()
            userList.add(UserData("Name: $names","Mobile No. : $number"))
            userAdapter.notifyDataSetChanged()
            Toast.makeText(this,"Updated Successfully",Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        addDialog.setNegativeButton("Cancel"){
            dialog,_->
            dialog.dismiss()
            Toast.makeText(this,"Cancel",Toast.LENGTH_SHORT).show()
        }

        addDialog.create()
        addDialog.show()






    }
// top 3 dots
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_mode,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id=item.itemId

        return when (id) {
            R.id.Dark_mode -> {

                if(flag==0){
                    contact_bg.setBackgroundColor(Color.BLACK)
                    flag=1
                }
                else if(flag==1){
                    contact_bg.setBackgroundColor(Color.WHITE)
                    flag=0
                }
                true
            }
            R.id.Crate -> {

                val inflter=LayoutInflater.from(this)
                val v=inflter.inflate(R.layout.contact_user_rating,null)

                //Set View
                val ratingBar=findViewById<RatingBar>(R.id.ratingBar)

                val addDialog=AlertDialog.Builder(this)
                addDialog.setView(v)
                addDialog.setPositiveButton("Ok"){
                        dialog,_->
                    val rating: String = java.lang.String.valueOf(ratingBar.rating)
                    dialog.dismiss()
                   Toast.makeText(this, rating, Toast.LENGTH_LONG).show()

                }

                addDialog.setNegativeButton("Cancel"){
                        dialog,_->
                    dialog.dismiss()
                    Toast.makeText(this,"Cancel",Toast.LENGTH_SHORT).show()
                }

                addDialog.create()
                addDialog.show()

                true
            }
            R.id.notify -> {
                Toast.makeText(this,"Notification is clicked",Toast.LENGTH_SHORT).show()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }


    }


}